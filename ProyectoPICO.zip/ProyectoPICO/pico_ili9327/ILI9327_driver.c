#include "ili9327_driver.h"
#include <stdio.h>

// Inicializa pines
void lcd_pins_init() {
    gpio_init(LCD_RS_PIN); gpio_set_dir(LCD_RS_PIN, GPIO_OUT);
    gpio_init(LCD_CS_PIN); gpio_set_dir(LCD_CS_PIN, GPIO_OUT);
    gpio_init(LCD_WR_PIN); gpio_set_dir(LCD_WR_PIN, GPIO_OUT);
    gpio_init(LCD_RD_PIN); gpio_set_dir(LCD_RD_PIN, GPIO_OUT);

    for (int i = 0; i < 8; i++) {
        gpio_init(LCD_DATA_START_PIN + i);
        gpio_set_dir(LCD_DATA_START_PIN + i, GPIO_OUT);
    }

    gpio_put(LCD_CS_PIN, 1);
    gpio_put(LCD_WR_PIN, 1);
    gpio_put(LCD_RD_PIN, 1);
}

// Escribe 8 bits al bus paralelo
void write_parallel_bus(uint8_t data) {
    const uint32_t mask = 0xFF << LCD_DATA_START_PIN;
    gpio_clr_mask(mask);
    gpio_set_mask((uint32_t)data << LCD_DATA_START_PIN);
    sleep_us(1); // estabilizar antes del WR
}

// Envía comando de 16 bits
void lcd_command(uint16_t cmd) {
    gpio_put(LCD_CS_PIN, 0);
    gpio_put(LCD_RS_PIN, 0);

    write_parallel_bus(cmd >> 8);
    gpio_put(LCD_WR_PIN, 0); gpio_put(LCD_WR_PIN, 1);

    write_parallel_bus(cmd & 0xFF);
    gpio_put(LCD_WR_PIN, 0); gpio_put(LCD_WR_PIN, 1);

    gpio_put(LCD_CS_PIN, 1);
}

// Envía dato de 16 bits
void lcd_data(uint16_t data) {
    gpio_put(LCD_CS_PIN, 0);
    gpio_put(LCD_RS_PIN, 1);

    write_parallel_bus(data & 0xFF);
    gpio_put(LCD_WR_PIN, 0); gpio_put(LCD_WR_PIN, 1);

    write_parallel_bus(data >> 8);
    gpio_put(LCD_WR_PIN, 0); gpio_put(LCD_WR_PIN, 1);

    gpio_put(LCD_CS_PIN, 1);
}

// Inicialización mínima
void ili9327_init(void) {
    lcd_pins_init();

    lcd_command(0x01); // Software Reset
    sleep_ms(120);

    lcd_command(0x11); // Sleep Out
    sleep_ms(120);

    // Power Control
    lcd_command(0xC0); lcd_data(0x26); lcd_data(0x09); lcd_data(0x08); lcd_data(0x08);
    lcd_command(0xC1); lcd_data(0x10); lcd_data(0x10); lcd_data(0x22); lcd_data(0x02);
    lcd_command(0xC5); lcd_data(0x3E); lcd_data(0x28); // VCOM

    // Memory Access Control (orientación y orden de color)
    lcd_command(0x36); lcd_data(0x48); // MX, BGR

    // Pixel Format
    lcd_command(0x3A); lcd_data(0x55); // 16-bit RGB565

    // Gamma
    lcd_command(0x26); lcd_data(0x01); // Gamma curve
    lcd_command(0xE0); // Positive gamma
    lcd_data(0x0F); lcd_data(0x1A); lcd_data(0x0F); lcd_data(0x18);
    lcd_data(0x2F); lcd_data(0x28); lcd_data(0x20); lcd_data(0x22);
    lcd_data(0x1F); lcd_data(0x1B); lcd_data(0x23); lcd_data(0x37);
    lcd_data(0x00); lcd_data(0x07); lcd_data(0x02); lcd_data(0x10);

    lcd_command(0xE1); // Negative gamma
    lcd_data(0x0F); lcd_data(0x1B); lcd_data(0x0F); lcd_data(0x17);
    lcd_data(0x33); lcd_data(0x2C); lcd_data(0x29); lcd_data(0x2E);
    lcd_data(0x30); lcd_data(0x30); lcd_data(0x39); lcd_data(0x3F);
    lcd_data(0x00); lcd_data(0x07); lcd_data(0x03); lcd_data(0x10);

    // Display ON
    lcd_command(0x29);
    sleep_ms(20);
}
// Llenar pantalla completa
void ili9327_fill_screen(uint16_t color) {
    lcd_command(0x2A);
    lcd_data(0x00); lcd_data(0x00);
    lcd_data((LCD_WIDTH-1) >> 8);
    lcd_data((LCD_WIDTH-1) & 0xFF);

    //lcd_command(0x2B);
    //lcd_data(0x00); lcd_data(0x00);
    //lcd_data((LCD_HEIGHT-1) >> 8);
    //lcd_data((LCD_HEIGHT-1) & 0xFF);
    lcd_command(0x2B);
    lcd_data(0x00); lcd_data(0x00); // y_start
    lcd_data(0x01); lcd_data(0x8F); // y_end = 399


    lcd_command(0x2C);
    for (int i = 0; i < LCD_WIDTH * (LCD_HEIGHT+2); i++) {
        lcd_data(color);
    }
}

// Dibujar un solo pixel
void draw_single_pixel(uint16_t x, uint16_t y, uint16_t color) {
    lcd_command(0x2A);
    lcd_data(x >> 8); lcd_data(x & 0xFF);
    lcd_data(x >> 8); lcd_data(x & 0xFF);

    lcd_command(0x2B);
    lcd_data(y >> 8); lcd_data(y & 0xFF);
    lcd_data(y >> 8); lcd_data(y & 0xFF);

    lcd_command(0x2C);
    lcd_data(color);
}