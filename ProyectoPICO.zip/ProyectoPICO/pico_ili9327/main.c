#include <stdio.h>
#include "pico/stdlib.h"
#include "ili9327_driver.h"

void ili9327_fill_screen_test(uint16_t color) {
    int heights[] = {400, 402, 404, 432};  // variantes a probar
    int num_tests = sizeof(heights) / sizeof(heights[0]);

    for (int t = 0; t < num_tests; t++) {
        int h = heights[t];
        int total_pixels = LCD_WIDTH * h;

        // Definir ventana completa
        lcd_command(0x2A); // Column
        lcd_data(0x00); lcd_data(0x00);
        lcd_data((LCD_WIDTH-1) >> 8);
        lcd_data((LCD_WIDTH-1) & 0xFF);

        lcd_command(0x2B); // Page
        lcd_data(0x00); lcd_data(0x00);
        lcd_data((h-1) >> 8);
        lcd_data((h-1) & 0xFF);

        // Escribir memoria
        lcd_command(0x2C);
        for (int i = 0; i < total_pixels; i++) {
            lcd_data(color);
        }

        // Pausa para observar
        printf("Fill test con altura %d\n", h);
        sleep_ms(1500);
    }
}

int main() {
    stdio_init_all();
    ili9327_init();

    // Probar con rojo
    ili9327_fill_screen_test(0xF800);

    // Probar con verde
    ili9327_fill_screen_test(0x07E0);

    // Probar con azul
    ili9327_fill_screen_test(0x001F);

    // Probar con blanco
    ili9327_fill_screen_test(0xFFFF);

    // Probar con negro
    ili9327_fill_screen_test(0x0000);

    while (true) {}
}