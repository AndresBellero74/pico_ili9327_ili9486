#ifndef ILI9327_DRIVER_H
#define ILI9327_DRIVER_H

#include "pico/stdlib.h"

#define LCD_WIDTH  240
#define LCD_HEIGHT 432

// Pines de Control (¡PIN RST ELIMINADO!)
#define LCD_RS_PIN 16  // Data/Command select (A0)
#define LCD_CS_PIN 17  // Chip select (CS)
#define LCD_WR_PIN 18  // Write strobe (WR)
#define LCD_RD_PIN 19  // Read strobe (RD) - Opcional

// Pines de Datos (Bus de 8 bits)
#define LCD_DATA_START_PIN 0  // El primer pin del bus de datos (D0)

// Funciones expuestas
void lcd_pins_init(void);
void write_parallel_bus(uint8_t data);
void lcd_command(uint16_t cmd);
void lcd_data(uint16_t data);
void ili9327_init(void);
void ili9327_fill_screen(uint16_t color);
void draw_single_pixel(uint16_t x, uint16_t y, uint16_t color);

#endif // ILI9327_DRIVER_H